Sending you database backup in two differnt way :

1. Sending SQL file
2. Sending complete .BAK file 

You may use any one which is fine with you. 

